# Marwaita-Icons
Icon pack for linux
