import subprocess
from pathlib import Path

import gi

gi.require_version("Gtk", "4.0")
from gi.repository import Gtk, Gdk, GLib

from utils import get_wallpapers, get_current_wallpaper, set_current_wallpaper
from thumbnail import get_thumbnail_path

ANIMATION_DURATION_MS = 220


def ease_out_cubic(t):
    return 1 - (1 - t) ** 3


class WallpaperWindow(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app)

        self.set_title("Wallpaper Switcher")
        self.set_default_size(1920, 1080)
        self.fullscreen()
        self.set_decorated(False)

        self.wallpapers = get_wallpapers()
        self.selected_index = self.find_current_index()

        backdrop_path = Path.home() / ".cache/logout-wallpaper.png"

        self.overlay = Gtk.Overlay()

        if backdrop_path.exists():
            self.backdrop = Gtk.Picture.new_for_filename(str(backdrop_path))
            self.backdrop.set_content_fit(Gtk.ContentFit.COVER)
            self.backdrop.set_hexpand(True)
            self.backdrop.set_vexpand(True)
            self.overlay.set_child(self.backdrop)

        self.scroller = Gtk.ScrolledWindow()
        self.scroller.set_policy(Gtk.PolicyType.EXTERNAL, Gtk.PolicyType.NEVER)
        self.scroller.set_vexpand(True)
        self.scroller.set_hexpand(True)

        self.row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        self.row.set_halign(Gtk.Align.CENTER)
        self.row.set_valign(Gtk.Align.CENTER)
        self.row.set_margin_start(40)
        self.row.set_margin_end(40)

        self.cards = []

        for wallpaper in self.wallpapers:
            card = self.build_card(wallpaper)
            self.row.append(card)
            self.cards.append(card)

        self.scroller.set_child(self.row)
        self.overlay.add_overlay(self.scroller)

        self.set_child(self.overlay)

        GLib.timeout_add(150, self.initial_scroll)

        controller = Gtk.EventControllerKey()
        controller.connect("key-pressed", self.on_key_pressed)
        self.add_controller(controller)

    def initial_scroll(self):
        self.update_selection(animate=False)
        return False

    def find_current_index(self):
        current = get_current_wallpaper()

        if current is None:
            return 0

        for i, wallpaper in enumerate(self.wallpapers):
            if wallpaper.resolve() == current.resolve():
                return i

        return 0

    def build_card(self, wallpaper):
        thumb_path = get_thumbnail_path(wallpaper)

        picture = Gtk.Picture.new_for_filename(str(thumb_path))
        picture.set_content_fit(Gtk.ContentFit.COVER)
        picture.set_size_request(420, 260)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        box.add_css_class("wallpaper-card")
        box.append(picture)

        box.picture = picture

        return box

    def update_selection(self, animate=True):
        for i, card in enumerate(self.cards):
            card.remove_css_class("selected")
            card.add_css_class("skewed")

            if i == self.selected_index:
                card.add_css_class("selected")
                target_size = (700, 440)
            else:
                target_size = (420, 260)

            if animate:
                self.animate_size(card.picture, target_size)
            else:
                card.picture.set_size_request(*target_size)

        self.row.queue_resize()
        self.scroll_to_selected(animate=animate)

    def animate_size(self, picture, target_size):
        start_w, start_h = picture.get_size_request()
        target_w, target_h = target_size

        if start_w == target_w and start_h == target_h:
            return

        start_time = None

        def on_tick(widget, frame_clock):
            nonlocal start_time
            now = frame_clock.get_frame_time()

            if start_time is None:
                start_time = now

            elapsed_ms = (now - start_time) / 1000
            progress = min(elapsed_ms / ANIMATION_DURATION_MS, 1.0)
            eased = ease_out_cubic(progress)

            w = start_w + (target_w - start_w) * eased
            h = start_h + (target_h - start_h) * eased

            widget.set_size_request(int(w), int(h))

            return progress < 1.0

        picture.add_tick_callback(on_tick)

    def scroll_to_selected(self, animate=True):
        card = self.cards[self.selected_index]

        success, bounds = card.compute_bounds(self.row)
        if not success:
            return

        card_x = bounds.origin.x
        card_width = bounds.size.width

        adj = self.scroller.get_hadjustment()
        viewport_width = self.scroller.get_width()

        target = card_x - (viewport_width / 2) + (card_width / 2)

        if not animate:
            adj.set_value(target)
            return

        self.animate_scroll(adj, target)

    def animate_scroll(self, adj, target):
        start_value = adj.get_value()

        if abs(start_value - target) < 1:
            return

        start_time = None

        def on_tick(widget, frame_clock):
            nonlocal start_time
            now = frame_clock.get_frame_time()

            if start_time is None:
                start_time = now

            elapsed_ms = (now - start_time) / 1000
            progress = min(elapsed_ms / ANIMATION_DURATION_MS, 1.0)
            eased = ease_out_cubic(progress)

            value = start_value + (target - start_value) * eased
            adj.set_value(value)

            return progress < 1.0

        self.scroller.add_tick_callback(on_tick)

    def on_key_pressed(self, controller, keyval, keycode, state):
        if keyval == Gdk.KEY_Escape:
            self.close()
        elif keyval == Gdk.KEY_Right:
            if self.selected_index < len(self.wallpapers) - 1:
                self.selected_index += 1
                self.update_selection()
        elif keyval == Gdk.KEY_Left:
            if self.selected_index > 0:
                self.selected_index -= 1
                self.update_selection()
        elif keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter):
            self.apply_wallpaper()

    def apply_wallpaper(self):
        wallpaper = self.wallpapers[self.selected_index]
        script = "/home/jordan/.config/scripts/wallpaper-change.sh"
        subprocess.Popen(
            [script, str(wallpaper)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        set_current_wallpaper(wallpaper)
        self.close()