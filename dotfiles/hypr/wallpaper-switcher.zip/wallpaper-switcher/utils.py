from pathlib import Path

WALLPAPER_DIR = Path("/home/jordan/Pictures/Wallpapers")

SUPPORTED = {
    ".jpg",
    ".jpeg",
    ".png",
    ".webp",
    ".bmp"
}


def get_wallpapers():
    wallpapers = []

    for ext in SUPPORTED:
        wallpapers.extend(WALLPAPER_DIR.rglob(f"*{ext}"))
        wallpapers.extend(WALLPAPER_DIR.rglob(f"*{ext.upper()}"))

    wallpapers.sort()

    return wallpapers


STATE_FILE = Path.home() / ".config/hypr/wallpaper-switcher/current.txt"


def get_current_wallpaper():
    """Read the last wallpaper applied through this app, falling back to Waypaper's config."""
    if STATE_FILE.exists():
        value = STATE_FILE.read_text().strip()
        if value:
            return Path(value)

    config_path = Path.home() / ".config/waypaper/config.ini"

    if not config_path.exists():
        return None

    with open(config_path) as f:
        for line in f:
            if line.strip().startswith("wallpaper ="):
                value = line.split("=", 1)[1].strip()
                value = value.replace("~", str(Path.home()), 1) if value.startswith("~") else value
                return Path(value)

    return None


def set_current_wallpaper(wallpaper_path: Path):
    """Record the wallpaper this app just applied, so next launch highlights it correctly."""
    STATE_FILE.write_text(str(wallpaper_path))